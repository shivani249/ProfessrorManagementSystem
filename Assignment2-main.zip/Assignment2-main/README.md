# Assignment 2 
Proffesor mangement sytem
there are 2 tables 1 manager and 2nd proffesor one manager can have many proffesors 
the rest api is shown 
there is additional patch hhtpverb for specifically updating the salary of specific proffesor
PMS LAYERED IS PROFFESOR MANAGEMENT SYSTEM USING LAYERED ARCHITECHTURE
